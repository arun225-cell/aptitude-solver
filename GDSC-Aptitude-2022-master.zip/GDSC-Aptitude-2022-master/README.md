# GDSC-Aptitude-2022

# Method 1 : CLI

## How to contribute?
    
    Step 1 : Fork the project repository
    Step 2 : Clone your fork
    Step 3 : Navigate to your local repository
    Step 4 : Check that your fork is the "origin" remote
    Step 5 : Add the project repository as the "upstream" remote
    Step 6 : Pull the latest changes from upstream into your local repository
    Step 7 : Create a new branch
    Step 8 : Make changes in your local repository
    Step 9 : Commit your changes
    Step 10 : Push your changes to your fork
    
  
 # Method 2 : GitHub Portal
 
 
## HOW TO CONTRIBUTE?


# Step 1 : Fork Repo

# Step 2 : Commit Changes by adding the answers of the questions

# Step 3 : Create Pull Request


###                 Begin the pull request!!!
20)In a clock, the time is 3.25.What is the angle between the hour hand and the minute hand of the clock:
A. 95/2 degrees
B. 90/3 degrees
C. 94/3 degrees
D. 95/3 degrees

Ans:(A)95/2 degrees
